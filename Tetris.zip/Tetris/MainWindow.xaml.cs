﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tetris
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //기존 이미지를 게임 png로 교체
        //코드 순서는 ID와 같도록
        private readonly ImageSource[] tileImages = new ImageSource[]
        {
            new BitmapImage(new Uri("Assets/TileEmpty.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/TileCyan.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/TileBlue.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/TileOrange.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/TileYellow.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/TileGreen.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/TilePurple.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/TileRed.png", UriKind.Relative))
        };
        private readonly ImageSource[] blockImages = new ImageSource[]
        {
            new BitmapImage(new Uri("Assets/Block-Empty.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Block-I.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Block-J.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Block-L.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Block-O.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Block-S.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Block-T.png", UriKind.Relative)),
            new BitmapImage(new Uri("Assets/Block-Z.png", UriKind.Relative)),
        };
        private readonly Image[,] imageControls; //이미지 컨트롤의 2차원 배열
        private readonly int maxDelay = 1000;
        private readonly int minDelay = 75;
        private readonly int delayDecrease = 25;
        
        private GameState gameState = new GameState(); //게임 상태 객체
        

        public MainWindow()
        {
            InitializeComponent();
            imageControls = SetupGameCanvas(gameState.GameGrid);//이미지 컨트롤 배열을 초기화
        }
        private Image[,] SetupGameCanvas(GameGrid grid) //캔버스에서 이미지 컨트롤을 옳바르게 설정
        {
            //그리드의 모든 셀에 대해 하나의 이미지 컨트롤이 존재
            //이미지 컨트롤의 배열은 그리드와 마찬가지로 22개의 행과 10개의 열로 구성
            Image[,] imageControls = new Image[grid.Rows, grid.Columns];
            int cellSize = 25;

            //그리드(셀)만들기 (지뢰찾기랑 비슷)
            for (int r = 0; r < grid.Rows; r++)
            {
                for (int c = 0; c < grid.Columns; c++)
                {
                    Image imageControl = new Image
                    {
                        Width = cellSize,
                        Height = cellSize
                    };
                    //히든 그리드를 내부에서 안보이게 밀어내기
                    //+10을 한 이유는 죽었을 때 마지막 도형이 살짝 보이기 위해서
                    Canvas.SetTop(imageControl, (r - 2) * cellSize + 10); 
                    Canvas.SetLeft(imageControl, c * cellSize);

                    //이미지를 캔버스의 차트로 만들고 추가
                    GameCanvas.Children.Add(imageControl);
                    imageControls[r, c] = imageControl;
                }
            }
            return imageControls;
            //여기까지 모든 셀에 하나의 이미지를 담는 그리드 2차원 배열 설계
        }
        private void DrawGrid(GameGrid grid) //그리드 그리기
        {
            // 각 위치에 대한 ID를 얻고 이미지 소스를 설정
            for (int r = 0; r < grid.Rows; r++)
            {
                for (int c = 0;c < grid.Columns; c++)
                {
                    int id = grid[r, c];
                    imageControls[r, c].Opacity = 1; 
                    imageControls[r, c].Source = tileImages[id];//ID
                }
            }
        }
        private void DrawBlock(Block block) //블록 그리기
        {
            foreach (Position p in block.TilePositions())
            {
                imageControls[p.Row, p.Column].Opacity = 1;
                imageControls[p.Row, p.Column].Source = tileImages[block.Id];
            }
        }
        private void DrawNextBlock(BlockQueue blockQueue) //다음 블록 이미지 보이기
        {
            Block next = blockQueue.NextBlock;
            NextImage.Source = blockImages[next.Id];
        }
        private void DrawHeldBlock(Block heldBlock)
        {
            if (heldBlock == null)
            {
                HoldImage.Source = blockImages[0];
            }
            else
            {
                HoldImage.Source = blockImages[heldBlock.Id];
            }
        }
        private void DrawGhostBlock(Block block) //블록의 도착지점 미리 보기
        {
            //현재 블록의 타일 위치에 낙하 거리를 추가하여 블록이 착지할 셀을 서치
            int dropDistance = gameState.BlockDropDistance();

            foreach (Position p in block.TilePositions())
            {
                //Opacity = 0.25의 블록이 떨어진 후 유지되기 때문에 위 코드에서 Opacity = 1로 변경 
                imageControls[p.Row + dropDistance, p.Column].Opacity = 0.25; 
                imageControls[p.Row + dropDistance, p.Column].Source = tileImages[block.Id];

            }
        }
        private void Draw(GameState gameState) //그리드와 현재 블록 모두 그리기
        {
            DrawGrid(gameState.GameGrid);
            DrawGhostBlock(gameState.CurrentBlock);
            DrawBlock(gameState.CurrentBlock);
            DrawNextBlock(gameState.BlockQueue); //다음 블록 그리기
            DrawHeldBlock(gameState.HeldBlock); //잡혀있는 블록 그리기
            ScoreText.Text = $"Scpre : {gameState.Score}"; //현재 점수 그리기
        }
        
        private async Task GameLoop() //비동기 메소드
        {
            Draw(gameState);

            while (!gameState.GameOver)
            {
                int delay = Math.Max(minDelay, maxDelay - (gameState.Score  * delayDecrease));
                await Task.Delay(500);
                gameState.MoveBlockDown();
                Draw(gameState);
            }
            GameOverMenu.Visibility = Visibility.Visible;
            FinalScoreText.Text = $"Score : {gameState.Score}";
        }
        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (gameState.GameOver)
            {
                return;
            }
            switch (e.Key)
            {
                case Key.Left:
                    gameState.MoveBlockLeft(); 
                    break;
                case Key.Right:
                    gameState.MoveBlockRight();
                    break;
                case Key.Down:
                    gameState.MoveBlockDown();
                    break;
                case Key.Up:
                    gameState.RotateBlockCW();
                    break;
                case Key.Z:
                    gameState.RotateBlockCCW();
                    break;
                case Key.C:
                    gameState.HoldBlock();
                    break;
                case Key.Space:
                    gameState.DropBlock();
                    break;
                default:
                    return;
            }
            Draw(gameState);
        }
        private async void GameCanvas_Loaded(object sender, RoutedEventArgs e)
        {
            await GameLoop();
        }
        private async void PlayAgain_Click(object sender, RoutedEventArgs e)
        {
            gameState = new GameState();
            GameOverMenu.Visibility = Visibility.Hidden;
            await GameLoop();
        }
    }
}