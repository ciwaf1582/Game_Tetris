﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Tetris
{
    internal class GameState
    {
         
        private Block currentBlock; //현재 블록
        public Block CurrentBlock
        {
            get => currentBlock;
            private set
            {
                currentBlock = value;
                currentBlock.Reset();

                for (int i = 0; i < 2; i++) // 블록이 떨어질 때 2행만큼 더 내려서 완전한 모습부터 시작
                {
                    currentBlock.Move(1, 0);

                    if (!BlockFits())
                    {
                        currentBlock.Move(-1, 0);
                    }
                }
            }
        }
        //블록을 업데이트할 때 현재 블록에 대한 지원 필드가 있는 속성을 추가
        public GameGrid GameGrid { get; }
        public BlockQueue BlockQueue { get; }
        public bool GameOver { get; private set; }
        public int Score { get; private set; }
        public Block HeldBlock { get; private set; }
        public bool CanHold { get; private set; }
        
        public GameState()
        {
            GameGrid = new GameGrid(22, 10); //22행과 10개 열로 게임 그리드를 초기화
            BlockQueue = new BlockQueue();
            CurrentBlock = BlockQueue.GetAndUpdate();
            CanHold = true;
        }
        private bool BlockFits() //현재 블록이 올바른 위치에 있는지 확인하는 메소드
        {
            //회전이 가능한지 체크
            // 블록이 곂치거나 그리드 밖으로 벗어났다면...
            foreach (Position p in CurrentBlock.TilePositions())
            {
                if (!GameGrid.IsEmpty(p.Row, p.Column)) //만약 셀이 비어있지 않다면...
                {
                    return false;
                }
            }
            return true;
        }
        public void HoldBlock()
        {
            if (!CanHold) //잡을 수 없으면 리턴
            {
                return;
            }
            if (HeldBlock == null) //현재 잡혀있는 블록이 없으면
            {
                HeldBlock = currentBlock; //현재 블록을 잡고
                CurrentBlock = BlockQueue.GetAndUpdate(); //현재 블록은 대기중의 블록으로 수정
            }
            else //이미 잡혀있는 블록이 있고 한번 더 누르면
            {
                //temp를 이용하여 교체
                Block tmp = CurrentBlock;
                CurrentBlock = HeldBlock;
                HeldBlock = tmp;
            }
            CanHold = false; //한 블록에 재사용 방지
        }
        public void RotateBlockCW() //블록 시계방향 회전하는 메소드
        {
            CurrentBlock.RotateCW(); //현재 블록을 시계방향으로 회전

            if (!BlockFits()) //현재 블록의 위치가 옳바르지 않다면
            {
                CurrentBlock.RotateCCW(); //반시계반향으로 한번 더 움직여서 원위치
            }
        }
        public void RotateBlockCCW() //반시계 방향
        {
            CurrentBlock.RotateCCW();

            if (!BlockFits())
            {
                CurrentBlock.RotateCW();
            }
        }
        public void MoveBlockLeft() //왼쪽으로 이동
        {
            CurrentBlock.Move(0, -1);

            if (!BlockFits())
            {
                CurrentBlock.Move(0, 1);
            }
        }
        public void MoveBlockRight() //오른쪽으로 이동
        {
            CurrentBlock.Move(0, 1);

            if (!BlockFits())
            {
                CurrentBlock.Move(0, -1);
            }
        }
        private bool IsGameOver()
        {
            return !(GameGrid.IsRowEmpty(0) && GameGrid.IsRowEmpty(1)); //위에 숨겨진 행이 비어있지 않으면 게임오버
        }
        private void PlaceBlock() 
        {
            //그리드의 해당 위치를 블록의 위치와 동일하게 설정
            foreach (Position p in CurrentBlock.TilePositions())
            {
                GameGrid[p.Row, p.Column] = CurrentBlock.Id;
            }
            //그런 다음 잠재적으로 가득 찬 행을 모두 제거
            Score += GameGrid.ClearFullRows();

            if (IsGameOver())
            {
                GameOver = true;
            }
            else
            {
                CurrentBlock = BlockQueue.GetAndUpdate();
                CanHold = true;
            }
        }
        public void MoveBlockDown()
        {
            CurrentBlock.Move(1, 0);

            if (!BlockFits()) //블록이 아래로 갈 수 없다면
            {
                CurrentBlock.Move(-1, 0); //다시 올리고
                PlaceBlock(); //PlaceBlock호출
            }
        }
        private int TileDropDistance(Position p) // 해당 위치의 열의 빈 칸의 값
        {
            int drop = 0;

            while (GameGrid.IsEmpty(p.Row + drop + 1, p.Column)) //IsEmpty : 셀이 비어있는지 확인하는 메소드
            {
                drop++;
            }
            return drop;
        }
        public int BlockDropDistance()
        {
            int drop = GameGrid.Rows;

            foreach (Position p in CurrentBlock.TilePositions()) //TilePositions : 반복 return
            {
                drop = System.Math.Min(drop, TileDropDistance(p)); //Math Min : 최소 값만큼 
            }
            return drop;
        }
        public void DropBlock()
        {
            CurrentBlock.Move(BlockDropDistance(), 0);
            PlaceBlock();
        }
    }
}
