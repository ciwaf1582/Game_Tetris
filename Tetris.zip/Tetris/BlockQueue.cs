﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tetris
{
    internal class BlockQueue // 블록 대기상태
    {
        //재활용할 7개 블록의 인스턴스가 있는 블록 배열을 포함
        private readonly Block[] blocks = new Block[]
        {
            new IBlock(),
            new JBlock(),
            new LBlock(),
            new OBlock(),
            new SBlock(),
            new TBlock(),
            new ZBlock()
        };
        private readonly Random random = new Random(); //무작위 블록

        //마지막 블록이 랜덤으로 만들어 질 때 그 다음의 블록에 대한 속성
        public Block NextBlock { get; private set; } //화면에 다음 블록이 무엇인지 출력
        public BlockQueue()
        {
            NextBlock = RandomBlock();
        }
        private Block RandomBlock()
        {
            return blocks[random.Next(blocks.Length)]; // 블랙 배열중 랜덤으로 설정
        }
        //다음 블록을 반환 및 속성 업데이트
        public Block GetAndUpdate() //
        {
            Block block = NextBlock;

            do
            {
                NextBlock = RandomBlock();
            }
            while (block.Id == NextBlock.Id); //현 블록과 다음의 블록의 id가 같은걸 원치 않기에...

            return block;
        }
    }
}
