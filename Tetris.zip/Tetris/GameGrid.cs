﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tetris
{
    internal class GameGrid
    {
        private readonly int[,] grid; //행, 열
        //=================인덱스를 정의해서 배열에 쉽게 엑세스=================
        public int Rows { get; }              
        public int Columns { get; }
        //======================================================================
        public int this [int r, int c] //r : 행, c : 열
        {
            get => grid[r, c];
            set => grid[r, c] = value;
        }
        public GameGrid(int rows, int columns) // 그리드 크기 조정
        {
            // 행과 열의 수를 저장하고 배열을 초기화
            Rows = rows;
            Columns = columns;
            grid = new int[rows, columns];
        }
        public bool IsInside(int r, int c) //그리드 내부에 있는지 확인
        {
            return r >= 0 && r < Rows && c >= 0 && c < Columns;
        }
        public bool IsEmpty(int r, int c) //셀이 비어있는지 확인
        {
            return IsInside(r, c) && grid[r, c] == 0; //셀이 그리드 내부에 있어야 하며 배열의 해당 값이 0
        }
        //전체 행이 꽉 찼는지 확인
        public bool IsRowFull(int r) //매개변수 행
        {
            for (int c = 0; c < Columns; c++) //r의 행을 체크
            {
                if (grid[r, c] == 0) //지정된 행의 열 루프 중 0이 있다면 false
                {
                    return false;
                }
            }
            return true;
        }
        public bool IsRowEmpty(int r) // 비어있는지 확인
        {
            for (int c = 0; c < Columns; c++)
            {
                if (grid[r, c] != 0) //r의 행을 체크
                {
                    return false; //지정된 행의 열 루프 중 0이 없다면 false
                }
            }
            return true;
        }
        private void ClearRow(int r) // 행을 지우는 메소드 (행이 비어있는 곳이 없다면...)
        {
            for (int c = 0; c < Columns; c++) 
            {
                grid[r, c] = 0;  
            }
        }
        private void MoveRowDown(int r, int numRows) // ClearRow이 발생하면 바로 지워지고 위 행들이 아래로 떨어지는 메소드
        {
            for (int c = 0; c < Columns; c++) 
            {
                grid[r + numRows, c] = grid[r, c];
                grid[r, c] = 0;
            }
        }
        public int ClearFullRows()
        {
            int cleared = 0;

            for (int r = Rows - 1; r >= 0; r--) //현재 행이 가득 찼는지 확인 및 제거
            {
                if (IsRowFull(r)) // 지워진 행 수만큼 아래로 이동
                {
                    ClearRow(r);
                    cleared++;
                }
                else if (cleared > 0)
                {
                    MoveRowDown(r, cleared);
                }
            }
            return cleared; //지워진 행을 반환
        }
    }
}
