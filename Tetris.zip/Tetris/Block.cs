﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tetris
{
    public abstract class Block //추상 클래스 : 반드시 오버라이딩을 통해 사용 가능한 메소드
    {
        /*****************************생성자*****************************/
        protected abstract Position[][] Tiles { get; } //회전 상태의 타일 위치를 저장하는 2차원 위치 배열
        protected abstract Position StartOffset { get; }// 블록이 생성되는 초기 위치를 결정
        public abstract int Id { get; } // 블록 식별자 
        private int rotationState; // 현재 회전 상태
        private Position offset; // 블록의 현재 위치 오프셋을 나타내는 Position 객체

        public Block()
        {
            //생성할 때 오프셋을 초기화, 블록 생성 시 시작 위치를 기반으로 설정
            offset = new Position(StartOffset.Row, StartOffset.Column); 
        }
        //블록이 차지하는 그리드 위치를 반환하는 메소드
        public IEnumerable<Position> TilePositions()
        {
            foreach (Position p in Tiles[rotationState])
            {
                yield return new Position(p.Row + offset.Row, p.Column + offset.Column); //yield : 반복해서 return을 반환
                //현재 회전 상태의 타일 위치에 대해 반환
                //여러 패스로 작업을 수행해야 하는 경우, 반복자를 만드는 것이 강력하고 효율적인 접근 방식
            }
        } 
        public void RotateCW() //시계 방향으로 회전하는 메소드
        {
            rotationState = (rotationState + 1) % Tiles.Length;
        }
        public void RotateCCW() //반시계 방향으로 회전하는 메소드
        {
            if (rotationState == 0)
            {
                rotationState = Tiles.Length - 1;
            }
            else
            {
                rotationState--;
            }
        }
        public void Move(int rows, int columns)//블록을 주어진 수의 행과 열만큼 이동하는 메소드
        {
            offset.Row += rows; 
            offset.Column += columns;
        }
        public void Reset() //블록의 회전 상태와 위치를 초기 상태로 재설정
        {
            rotationState = 0;
            offset.Row = StartOffset.Row;
            offset.Column = StartOffset.Column;
        }
    }
}
