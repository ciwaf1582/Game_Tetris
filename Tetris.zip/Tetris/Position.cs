﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tetris
{
    public class Position // 기호 위치 (행과 열을 저장하고 반환)
    {
        public int Row { get; set; } //행
        public int Column { get; set; } //열
        public Position(int row, int column)
        {
            Row = row;
            Column = column;
        }
    }
}
