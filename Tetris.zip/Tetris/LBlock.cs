﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tetris
{
    internal class LBlock : Block // L 블록
    {
        private readonly Position[][] tiles = new Position[][]
        {
            new Position[] { new(0,2), new(1,0), new(1,1), new(1,2) },
            new Position[] { new(0,1), new(1,1), new(2,1), new(2,2) },
            new Position[] { new(1,0), new(1,1), new(1,2), new(2,0) },
            new Position[] { new(0,0), new(0,1), new(1,1), new(2,1) }
        };
        public override int Id => 3; // 블록 식별 id
        protected override Position StartOffset => new Position(0, 3); // 시작 블록 위치
        protected override Position[][] Tiles => tiles; //블록을 구성하는 타일들의 배열을 정의하는 속성
    }
}
